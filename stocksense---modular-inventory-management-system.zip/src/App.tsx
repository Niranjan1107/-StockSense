/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { InventoryProvider, useInventory } from './context/InventoryContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardView } from './components/dashboard/DashboardView';
import { ProductsView } from './components/products/ProductsView';
import { StockOverviewView } from './components/inventory/StockOverviewView';
import { ReorderingRulesView } from './components/products/ReorderingRulesView';
import { ReceiptsView } from './components/operations/ReceiptsView';
import { DeliveriesView } from './components/operations/DeliveriesView';
import { TransfersView } from './components/operations/TransfersView';
import { AdjustmentsView } from './components/operations/AdjustmentsView';
import { MoveHistoryView } from './components/operations/MoveHistoryView';
import { SettingsView } from './components/settings/SettingsView';
import { ProfileView } from './components/profile/ProfileView';
import { AuthPage } from './components/auth/AuthPage';

import { ProductModal } from './components/products/ProductModal';
import { NewReceiptModal } from './components/operations/NewReceiptModal';
import { NewDeliveryModal } from './components/operations/NewDeliveryModal';
import { NewTransferModal } from './components/operations/NewTransferModal';
import { NewAdjustmentModal } from './components/operations/NewAdjustmentModal';
import { Product } from './types/inventory';
import { RefreshCw } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Persisted desktop sidebar collapse state
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('stocksense_sidebar_collapsed');
      return saved ? JSON.parse(saved) : false;
    } catch {
      return false;
    }
  });

  // Modal states
  const [showProductModal, setShowProductModal] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [preselectedProductForReceipt, setPreselectedProductForReceipt] = useState<Product | null>(null);

  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);

  const [showAdjustmentModal, setShowAdjustmentModal] = useState(false);
  const [preselectedProductForAdjustment, setPreselectedProductForAdjustment] = useState<string | undefined>(undefined);

  // If session is still validating on initial boot
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white font-sans">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold mb-4 shadow-lg shadow-emerald-500/10">
          <RefreshCw className="w-6 h-6 animate-spin" />
        </div>
        <p className="text-sm font-semibold tracking-wider uppercase text-slate-400">
          Initializing StockSense Environment...
        </p>
      </div>
    );
  }

  // If unauthenticated: redirect directly to the comprehensive Login / Register / OTP flow!
  if (!isAuthenticated) {
    return <AuthPage />;
  }

  const handleEditProduct = (prod: Product) => {
    setProductToEdit(prod);
    setShowProductModal(true);
  };

  const handleNewProduct = () => {
    setProductToEdit(null);
    setShowProductModal(true);
  };

  const handleTriggerReceipt = (prod?: Product | null) => {
    setPreselectedProductForReceipt(prod || null);
    setShowReceiptModal(true);
  };

  const handleTriggerAdjustment = (productId?: string) => {
    setPreselectedProductForAdjustment(productId);
    setShowAdjustmentModal(true);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex text-slate-900 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isMobileOpen={isMobileOpen}
        setIsMobileOpen={setIsMobileOpen}
        isCollapsed={isCollapsed}
        setIsCollapsed={setIsCollapsed}
      />

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${
        isCollapsed ? 'lg:pl-20' : 'lg:pl-64'
      }`}>
        {/* Top Header Navigation */}
        <Header
          onToggleMobileNav={() => setIsMobileOpen(!isMobileOpen)}
          setActiveTab={setActiveTab}
          onOpenNewReceipt={() => handleTriggerReceipt(null)}
          onOpenNewDelivery={() => setShowDeliveryModal(true)}
          onOpenNewTransfer={() => setShowTransferModal(true)}
          onOpenNewAdjustment={() => handleTriggerAdjustment()}
          onOpenNewProduct={handleNewProduct}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          isCollapsed={isCollapsed}
        />

        {/* View Router */}
        <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              setActiveTab={setActiveTab}
              onOpenNewReceipt={() => handleTriggerReceipt(null)}
              onOpenNewDelivery={() => setShowDeliveryModal(true)}
              onOpenNewTransfer={() => setShowTransferModal(true)}
              onOpenNewAdjustment={() => handleTriggerAdjustment()}
            />
          )}

          {activeTab === 'products' && (
            <ProductsView
              onOpenNewProduct={handleNewProduct}
              onEditProduct={handleEditProduct}
              onQuickAdjust={handleTriggerAdjustment}
              onQuickReceive={(prodId) => handleTriggerReceipt(null)}
            />
          )}

          {activeTab === 'stock-overview' && <StockOverviewView />}

          {activeTab === 'reordering' && (
            <ReorderingRulesView
              onTriggerReceiptForProduct={(prod) => handleTriggerReceipt(prod)}
              onEditProductRules={handleEditProduct}
            />
          )}

          {activeTab === 'receipts' && (
            <ReceiptsView onOpenNewReceipt={() => handleTriggerReceipt(null)} />
          )}

          {activeTab === 'deliveries' && (
            <DeliveriesView onOpenNewDelivery={() => setShowDeliveryModal(true)} />
          )}

          {activeTab === 'transfers' && (
            <TransfersView onOpenNewTransfer={() => setShowTransferModal(true)} />
          )}

          {activeTab === 'adjustments' && (
            <AdjustmentsView onOpenNewAdjustment={() => handleTriggerAdjustment()} />
          )}

          {activeTab === 'move-history' && <MoveHistoryView />}

          {activeTab === 'settings' && <SettingsView initialTab="warehouses" />}

          {activeTab === 'categories' && <SettingsView initialTab="categories" />}

          {activeTab === 'profile' && <ProfileView />}
        </main>
      </div>

      {/* Global Modals */}
      <ProductModal
        isOpen={showProductModal}
        onClose={() => {
          setShowProductModal(false);
          setProductToEdit(null);
        }}
        productToEdit={productToEdit}
      />

      <NewReceiptModal
        isOpen={showReceiptModal}
        onClose={() => {
          setShowReceiptModal(false);
          setPreselectedProductForReceipt(null);
        }}
        preselectedProduct={preselectedProductForReceipt}
      />

      <NewDeliveryModal
        isOpen={showDeliveryModal}
        onClose={() => setShowDeliveryModal(false)}
      />

      <NewTransferModal
        isOpen={showTransferModal}
        onClose={() => setShowTransferModal(false)}
      />

      <NewAdjustmentModal
        isOpen={showAdjustmentModal}
        onClose={() => {
          setShowAdjustmentModal(false);
          setPreselectedProductForAdjustment(undefined);
        }}
        preselectedProductId={preselectedProductForAdjustment}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <InventoryProvider>
        <MainAppContent />
      </InventoryProvider>
    </AuthProvider>
  );
}
